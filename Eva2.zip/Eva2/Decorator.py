class DescuentoDecorador:
    def __init__(self, producto):
        self.producto = producto

    def aplicar_descuento(self, cantidad):
        if cantidad > 10:
            return self.producto.precio * 0.9
        else:
            return self.producto.precio