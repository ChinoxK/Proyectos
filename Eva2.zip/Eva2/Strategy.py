class DescuentoStrategy:
    def aplicar_descuento(self, tipo, producto, valor_descuento):
        if tipo == 'descuento_fijo':
            nuevo_precio = producto.precio - valor_descuento
            return max(nuevo_precio, 0)
        elif tipo == 'porcentaje_descuento':
            descuento = producto.precio * (valor_descuento / 100)
            nuevo_precio = producto.precio - descuento
            return max(nuevo_precio, 0)
