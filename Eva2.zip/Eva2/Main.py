from Singleton import AdministradorInventario
from Factory import FabricaProductos
from Observer import ObservadorPromocion
from Strategy import DescuentoStrategy
from Decorator import DescuentoDecorador

class CRUD:
    def __init__(self, admin_inventario):
        self.admin_inventario = admin_inventario
        self.observador_promocion = ObservadorPromocion()

    def crear_producto(self, tipo):
        nombre = input("Introduce el nombre del producto: ")
        precio = float(input("Introduce el precio del producto: "))
        producto = FabricaProductos().crear_producto(tipo, nombre, precio)
        self.admin_inventario.inventario[nombre] = producto

    def leer_producto(self):
        nombre = input("Introduce el nombre del producto: ")
        producto = self.admin_inventario.inventario.get(nombre)
        if producto:
            return f"Nombre: {producto.nombre}, Precio: {producto.precio}, Tipo: {producto.tipo}"
        else:
            return f"El producto {nombre} no existe en el inventario."

    def actualizar_producto(self, tipo):
        nombre = input("Introduce el nombre del producto a actualizar: ")
        if nombre in self.admin_inventario.inventario:
            precio = float(input("Introduce el nuevo precio del producto: "))
            producto_nuevo = FabricaProductos().crear_producto(tipo, nombre, precio)
            self.admin_inventario.inventario[nombre] = producto_nuevo
        else:
            print(f"El producto {nombre} no existe en el inventario.")

    def eliminar_producto(self):
        nombre = input("Introduce el nombre del producto a eliminar: ")
        if nombre in self.admin_inventario.inventario:
            del self.admin_inventario.inventario[nombre]
            print(f"El producto {nombre} ha sido eliminado del inventario.")
        else:
            print(f"El producto {nombre} no existe en el inventario.")

    def aplicar_descuento(self, tipo_descuento, nombre_producto):
        producto = self.admin_inventario.inventario.get(nombre_producto)
        if producto:
            if tipo_descuento == 'descuento_fijo':
                valor_descuento = float(input("Introduce el valor del descuento: "))
                estrategia_descuento = DescuentoStrategy()
                producto.precio = estrategia_descuento.aplicar_descuento('descuento_fijo', producto, valor_descuento)
            elif tipo_descuento == 'porcentaje_descuento':
                valor_descuento = float(input("Introduce el porcentaje de descuento: "))
                estrategia_descuento = DescuentoStrategy()
                producto.precio = estrategia_descuento.aplicar_descuento('porcentaje_descuento', producto, valor_descuento)
            else:
                print("Tipo de descuento no válido.")

            descuento_decorador = DescuentoDecorador(producto)
            producto.precio = descuento_decorador.aplicar_descuento(0)

            self.observador_promocion.actualizar(producto.nombre, producto.precio)

            return f"Nuevo descuento para {producto.nombre}: {valor_descuento}%, Precio con descuento: {producto.precio}"
        else:
            return f"El producto {nombre_producto} no existe en el inventario."

def main():
    admin_inventario = AdministradorInventario()

    crud = CRUD(admin_inventario)

    while True:
        print("\n1. Crear producto")
        print("2. Leer producto")
        print("3. Actualizar producto")
        print("4. Eliminar producto")
        print("5. Aplicar descuento")
        print("6. Salir")

        opcion = input("\nElige una opción: ")

        if opcion == '1':
            tipo = input("Introduce el tipo de producto (ProductosElectronicos, RopaProductos): ")
            crud.crear_producto(tipo)
        elif opcion == '2':
            print(crud.leer_producto())
        elif opcion == '3':
            tipo = input("Introduce el tipo de producto (ProductosElectronicos, RopaProductos): ")
            crud.actualizar_producto(tipo)
        elif opcion == '4':
            crud.eliminar_producto()
        elif opcion == '5':
            tipo_descuento = input("Introduce el tipo de descuento (descuento_fijo, porcentaje_descuento): ")
            nombre_producto = input("Introduce el nombre del producto al que aplicar el descuento: ")
            print(crud.aplicar_descuento(tipo_descuento, nombre_producto))
        elif opcion == '6':
            break
        else:
            print("Opción no válida. Por favor, elige una opción del menú.")

if __name__ == "__main__":
    main()
