class ObservadorPromocion:
    def __init__(self):
        self.descuentos = {}

    def actualizar(self, producto, descuento):
        self.descuentos[producto] = descuento
        print(f"Nuevo descuento para {producto}: {descuento}%")