class FabricaProductos:
    def crear_producto(self, tipo, nombre=None, precio=None):
        if tipo == 'ProductosElectronicos':
            return ProductosElectronicos(nombre, precio)
        elif tipo == 'RopaProductos':
            return RopaProductos(nombre, precio)

class ProductosElectronicos:
    def __init__(self, nombre, precio):
        self.nombre = nombre
        self.precio = precio
        self.tipo = 'Electronico'

class RopaProductos:
    def __init__(self, nombre, precio):
        self.nombre = nombre
        self.precio = precio
        self.tipo = 'Ropa'
