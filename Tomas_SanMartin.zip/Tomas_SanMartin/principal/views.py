from django.shortcuts import render
def verIndex(request):
    return render(request, 'index.html')

# Create your views here.
